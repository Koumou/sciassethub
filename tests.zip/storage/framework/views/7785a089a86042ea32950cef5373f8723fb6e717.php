<?php $__env->startSection('content'); ?>

<?php if(Session::has('ACCOUNT_CREATED')): ?>
<div class="container py-5">
    <div class="row  py-4 d-flex align-items-center justify-content-center">

    <div class="col-lg-6 col-md-7 col-sm-12">

            <div class="py-4">
                <img src="https://res.cloudinary.com/dzdngxtqx/image/upload/v1678128750/Eduassethub/Icons/envelop_gqrk9k.png" alt="envelop" width="15%" />
            </div>
            <h2 class="fs-title text-center"><b>Confirm your email</b></h2>

            <p>
                Your account has successfully created, but it currently inactive; In order to active your account, please click on the enclosed link within the email that has been dispatched to your inbox. In case you are unable to locate the email, we kindly request you to check your spam folder.
            </p>
            <div class="py-2">
                <a class="btn btn-secondary no-radius" href="/login">Ok</a>
            </div>

        </div>
    </div>
</div>

<?php elseif(Session::has('ACTIVE_ALREADY')): ?>
<div class="container py-5">
    <div class="row  py-4 d-flex align-items-center justify-content-center">

        <div class="col-lg-7 text-center">

            <div class="py-4">
                <img src="https://res.cloudinary.com/dzdngxtqx/image/upload/v1678130412/Eduassethub/Icons/check_i0mble.png" alt="envelop" width="15%" />
            </div>
            <h2 class="fs-title text-center"><b>Success</b></h2>

            <p>
                Your email address is already verified.
            </p>
            <div class="py-2">
                <a class="btn btn-secondary no-radius" href="/login">Ok</a>
            </div>

        </div>
    </div>
</div>

<?php elseif(Session::has('ACTIVE_SUCCESS')): ?>
<div class="container py-5">
    <div class="row  py-4 d-flex align-items-center justify-content-center">

        <div class="col-lg-7 text-center">

            <div class="py-4">
                <img src="https://res.cloudinary.com/dzdngxtqx/image/upload/v1678130412/Eduassethub/Icons/check_i0mble.png" alt="envelop" width="15%" />
            </div>
            <h2 class="fs-title text-center"><b>Success</b></h2>

            <p>
                Thank you for verifying your email address.
            </p>
            <div class="py-2">
                <a class="btn btn-secondary no-radius" href="/login">Ok</a>
            </div>

        </div>
    </div>
</div>
<?php else: ?>



<div class="container py-5">
    <div class="row  py-4 d-flex align-items-center justify-content-center">
        <div class="col-lg-5">
            <div class="card mx-0 px-0">
                <div class="card-body">
                    <div class="col-lg-12 mx-0 px-0">
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong>Oops!</strong> <br />
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php endif; ?>
                    </div>
                    <form id="msform" method="POST" action="<?php echo e(route('login')); ?>" data-netlify-recaptcha="true" data-netlify="true">
                        <?php echo e(csrf_field()); ?>


                        <fieldset>
                            <div class="form-card">
                                <div class="py-2 pb-2">
                                    <div>
                                        <h2 class="fs-title"><b>Log In</b></h2>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="fieldlabels">Email: <b class="text-danger">*</b></label>
                                    <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Enter email" autofocus>
                                </div>


                                <div class="form-group">
                                    <label class="fieldlabels">Password: <b class="text-danger">*</b></label>
                                    <input type="password" name="password" placeholder="Enter Password" />
                                    <!-- <div class="mt-4 " ><a href=""><b style="font-size: small; color:dodgerblue;">Forgot password?</b></a></div> -->
                                </div>
                                <div><a href="reset_password"><b style="font-size: small; color:dodgerblue;">Forgot password?</b></a></div>

                            </div>

                            <input type="button" name="next" class="next action-button" value="Login" />


                        </fieldset>

                        <fieldset>
                            <div class="form-card">
                                <div class="py-2 pb-4">
                                    <div class="pb-4">
                                        <h2 class="fs-title"><b>Log In</b></h2>
                                    </div>
                                    It seems like you are attempting to log in. For security reasons, we need to verify if you are logging in on behalf of the account owner. Can you please confirm if you are authorized to access this account?
                                </div>

                            </div>
                            <div class="form-group py-3 pb-2">


                                <input type="submit" id="yes_login_attempt" class="btn btn-secondary no-radius action-button float-left" name="login_attempt" value="Yes" onclick="<?php $value = "yes";

                                                                                                                                                                                    Illuminate\Support\Facades\Cookie::queue('account_owner', $value, 360); ?>">

                                <input type="submit" id="no_login_attempt" class="btn btn-danger no-radius action-button float-right" name="login_attempt" value="No" onclick="<?php $value = "no";
                                                                                                                                                                                Illuminate\Support\Facades\Cookie::queue('account_owner', $value, 360); ?>">

                                <!-- <button type="submit" class="btn btn-danger float-left no-radius">Cancel</button>

                                <button type="submit" class="btn btn-success float-right no-radius">I UNDERSTAND</button> -->
                            </div>
                        </fieldset>


                    </form>

                </div>
            </div>

            <div class="my-4 rounded">
                <center>
                  <p style="font-size: small; padding-bottom: 0px    ">  Don't have an account? <a href="/register"><b style="color:dodgerblue;">Create account</b></a></p>
                </center>
            </div>

        </div>



    </div>
</div>



<?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.style_guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\latest\eduassethub\eduassethub\resources\views/auth/login.blade.php ENDPATH**/ ?>