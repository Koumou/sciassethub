

<?php $__env->startSection('content'); ?>

<?php if(Session::has('ACCOUNT_CREATED')): ?>
<div class="container py-5">
    <div class="row  py-4 d-flex align-items-center justify-content-center">

        <div class="col-lg-7 text-center">

            <div class="py-4">
                <img src="https://res.cloudinary.com/dzdngxtqx/image/upload/v1678128750/Eduassethub/Icons/envelop_gqrk9k.png" alt="envelop" width="15%" />
            </div>
            <h2 class="fs-title text-center"><b>Confirm your email</b></h2>

            <p>
                Your account has successfully created, but it currently inactive; In order to active your account, please click on the enclosed link within the email that has been dispatched to your inbox. In case you are unable to locate the email, we kindly request you to check your spam folder.
            </p>
            <div class="py-2">
                <a class="btn btn-secondary no-radius" href="/login">Ok</a>
            </div>

        </div>
    </div>
</div>

<?php elseif(Session::has('ACTIVE_ALREADY')): ?>
<div class="container py-5">
    <div class="row  py-4 d-flex align-items-center justify-content-center">

        <div class="col-lg-7 text-center">

            <div class="py-4">
                <img src="https://res.cloudinary.com/dzdngxtqx/image/upload/v1678130412/Eduassethub/Icons/check_i0mble.png" alt="envelop" width="15%" />
            </div>
            <h2 class="fs-title text-center"><b>Success</b></h2>

            <p>
                Your email address is already verified.
            </p>
            <div class="py-2">
                <a class="btn btn-secondary no-radius" href="/login">Ok</a>
            </div>

        </div>
    </div>
</div>

<?php elseif(Session::has('ACTIVE_SUCCESS')): ?>
<div class="container py-5">
    <div class="row  py-4 d-flex align-items-center justify-content-center">

        <div class="col-lg-7 text-center">

            <div class="py-4">
                <img src="https://res.cloudinary.com/dzdngxtqx/image/upload/v1678130412/Eduassethub/Icons/check_i0mble.png" alt="envelop" width="15%" />
            </div>
            <h2 class="fs-title text-center"><b>Success</b></h2>

            <p>
                Thank you for verifying your email address.
            </p>
            <div class="py-2">
                <a class="btn btn-secondary no-radius" href="/login">Ok</a>
            </div>

        </div>
    </div>
</div>
<?php endif; ?>

<div class="container py-5">
    <div class="row  py-4 d-flex align-items-center justify-content-center">
        <form id="msform" method="POST" action="<?php echo e(route('search.request')); ?>" data-netlify-recaptcha="true" data-netlify="true">
            <?php echo e(csrf_field()); ?>


            <center>
                <div class="col-lg-8">
                    <div class="input-group py-2">


                        <input type="text" class="form-control outline-0" name="input_insert" placeholder="Type asset name" onkeyup="if(this.value.length > 2) document.getElementById('start_button').disabled = false; else document.getElementById('start_button').disabled = true;">
                        <div class="input-group-append">
                            <button class="btn btn-secondary ml-3 text-white" type="submit" id="start_button" disabled>
                                Search
                            </button>
                        </div>

                    </div>
                </div>
            </center>
        </form>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $('#textarea').on('keypress keyup keydown', function() {
            if ($('#textarea').val() == "") {
                $('#savebtn').prop('disabled', true);
            } else {
                $('#savebtn').prop('disabled', false);
            }
        });
    </script>
</div>


<?php if(Cache::has('asset_search') || Cache::has('asset_search1')): ?>
<?php

// dd(Illuminate\Support\Facades\Cache::get('asset_search1'));
$cache_asset_search = Illuminate\Support\Facades\Cache::get('asset_search');
$cache_asset_search1 = Illuminate\Support\Facades\Cache::get('asset_search1');
$cache_input_inserted = Illuminate\Support\Facades\Cache::get('input_inserted');
$cache_input_ChapGPT = Illuminate\Support\Facades\Cache::get('ChapGPT');



// dd(count($cache_asset_search) == 0 , count($cache_asset_search1));
?>

<?php if(count($cache_asset_search) == 0 && count($cache_asset_search1) == 0): ?>
<div class="container py-5">

    <div class="pt-5">
        <p>About 0 results</p>
        <di>Your search - <?php echo e($cache_input_inserted); ?> - did not match any documents.</di>
    </div>
</div>

<?php else: ?>

<div class="container py-0">

    <div class="pt-0">
        <div><small>About <?php echo e(count($cache_asset_search) + count($cache_asset_search1)); ?> results</small></div>
        <div><small>Your search - <?php echo e($cache_input_inserted); ?> - did not match any documents.</small></div>
        <br />
        <br />
    </div>


    <div class="row py-4">
        <!-- ChapGPT -->
        <div class="order-card auto-fill__">

            <!-- Begin _ Asset -->
            <?php $__currentLoopData = $cache_asset_search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset_available): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php

            $asset_name_decrypt = $asset_available->asset_name;
            $asset_min_value_decrypt = Illuminate\Support\Facades\Crypt::decrypt($asset_available->min_value);
            $asset_max_value_decrypt = Illuminate\Support\Facades\Crypt::decrypt($asset_available->max_value);
            $asset_unit_measurement_decrypt = Illuminate\Support\Facades\Crypt::decrypt($asset_available->unit_measurement);
            $asset_asset_category_decrypt = Illuminate\Support\Facades\Crypt::decrypt($asset_available->asset_category);
            $owner_firstname = Illuminate\Support\Facades\Crypt::decrypt($asset_available->firstname);
            $owner_lastname = Illuminate\Support\Facades\Crypt::decrypt($asset_available->lastname);
            $owner_full_name = $owner_firstname . " " . $owner_lastname;
            ?>

            <a href="all_asset_available/asset_preview/<?php echo e($asset_available->asset_reference); ?>">

                <div class="panel panel-default card-input card">
                    <div class="card-body border-0">
                        <div class="panel-heading pb-2 myGallery">
                            <div class="item">

                                <img src="<?php echo e(asset($asset_available->asset_image)); ?>" class="asset_avaiable">
                            </div>
                        </div>
                        <p class="text-dark my-1 py-1 mx-0">
                            <b><?php echo e($asset_name_decrypt); ?></b>
                            <span class="pl-3">
                                <?php if($asset_available->ar_demo != 'no'): ?>
                                <img src="https://res.cloudinary.com/dzdngxtqx/image/upload/v1691847793/Sciassethub/img/AR_j7bpeu.png" width="35">
                                <?php endif; ?>
                            </span>

                            <?php if($asset_asset_category_decrypt == "Chemical"): ?>
                            <a tabindex="-1" id="testPop" title="Chemical formula" data-content="Formaldehyde, acetic acid, glucose" data-toggle="popover" data-trigger="focus" data-placement="bottom" data-container="body" data-viewport=".container">
                                <i class="fa fa-info-circle"></i>
                            </a>
                            <?php endif; ?>
                        </p>
                        <div>
                            <small class="pb-3 mb-3">
                                Quantity in storage: <?php echo e(gzuncompress($asset_max_value_decrypt)); ?> <?php echo e(ucfirst(gzuncompress($asset_unit_measurement_decrypt))); ?>

                            </small>
                            <br />
                            <div class="container-controller py-2">
                                <div class="float-left">
                                    <!-- <div class="bleed-left"></div> -->
                                    <div class="user_profile_01">
                                        <span class="text-white"><?php echo e(\App\Providers\AppServiceProvider::FirstLetter($owner_full_name)); ?></span>
                                    </div>
                                </div>
                                <div class="float-right">
                                    <div><b><?php echo e($owner_firstname); ?> <?php echo e($owner_lastname); ?></b></div>
                                    <!-- <div class="pt-0"><small>Asset added <?php echo e(\App\Providers\AppServiceProvider::difference_between_timestamp($asset_available->created_at)); ?></small></div>
                                    <br /> -->

                                    <?php echo e($cache_input_ChapGPT); ?>;

                                </div>
                            </div>
                        </div>
                        <div>
                            <p>
                            </p>
                        </div>
                    </div>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- End Asset -->


            <!-- Begin Space -->
            <?php
            ?>
            <?php if(count($cache_asset_search1) !=0): ?>
            <?php $__currentLoopData = $cache_asset_search1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset_available): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php

            $type_decrypt = Illuminate\Support\Facades\Crypt::decrypt($asset_available->type_storage);
            $storage_brand_decrypt = Illuminate\Support\Facades\Crypt::decrypt($asset_available->storage_brand);
            $low_decrypt = Illuminate\Support\Facades\Crypt::decrypt($asset_available->temperature_range_l);
            $high_decrypt = Illuminate\Support\Facades\Crypt::decrypt($asset_available->temperature_range_h);
            $storage_location_building_decrypt = Illuminate\Support\Facades\Crypt::decrypt($asset_available->storage_location_building);
            $co2_decrypt = Illuminate\Support\Facades\Crypt::decrypt($asset_available->co2);
            $owner_firstname = Illuminate\Support\Facades\Crypt::decrypt($asset_available->firstname);
            $owner_lastname = Illuminate\Support\Facades\Crypt::decrypt($asset_available->lastname);
            $owner_full_name = $owner_firstname . " " . $owner_lastname;
            ?>


            <a href="/rent_space_available/preview_rent_space_available/<?php echo e($asset_available->rent_place_id); ?>">


                <div class="panel panel-default card-input card">
                    <div class="card-body border-0">
                        <!-- <div class="panel-heading pb-2 myGallery">
                            <div class="item">
                                <img src="<?php echo e(asset($asset_available->frontal_img)); ?>" class="asset_avaiable">
                            </div>
                        </div> -->
                        <p class="text-dark my-1 py-1 mx-0">
                            <b><?php echo e(gzuncompress($type_decrypt)); ?>: Brand (<?php echo e(gzuncompress($storage_brand_decrypt)); ?>)</b>
                            <br />
                        <div>Location: <?php echo e(gzuncompress($storage_location_building_decrypt)); ?></div>
                        <div>TR: <?php echo e(gzuncompress($low_decrypt)); ?>°C (low) ~ <?php echo e(gzuncompress($high_decrypt)); ?>°C (high)</div>
                        <?php if(gzuncompress($co2_decrypt) == "Yes"): ?>
                        <span class="badge badge-pill badge-dark mt-2">CO<sub class="text-white">2</sub></span>
                        <?php endif; ?>
                        </p>
                        <div>

                            <div class="container-controller py-2">
                                <div class="float-left">
                                    <!-- <div class="bleed-left"></div> -->
                                    <div class="user_profile_01">
                                        <span class="text-white"><?php echo e(\App\Providers\AppServiceProvider::FirstLetter($owner_full_name)); ?></span>
                                    </div>
                                </div>
                                <div class="float-right">
                                    <div><b><?php echo e($owner_firstname); ?> <?php echo e($owner_lastname); ?></b></div>
                                    <!-- <div class="pt-0"><small>Asset added <?php echo e(\App\Providers\AppServiceProvider::difference_between_timestamp($asset_available->created_at)); ?></small></div> -->
                                    </p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <!-- End space -->

        </div>


    </div>
</div>
<?php endif; ?>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.style_guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\latest\eduassethub\eduassethub\resources\views/common/search.blade.php ENDPATH**/ ?>