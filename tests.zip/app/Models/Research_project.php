<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Research_project extends Model
{
    use HasFactory;

    protected $guarded = [];
    protected $table = 'research_project';
}
